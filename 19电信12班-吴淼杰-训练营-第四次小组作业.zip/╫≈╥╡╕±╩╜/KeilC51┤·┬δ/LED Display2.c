#include <reg52.h>
typedef unsigned char u8;
typedef unsigned int  u16;
sbit seg_sel = P1^4;
sbit bit_sel = P1^5;
#define DATA P0
u8 code seg_tab[] = {
								0xc0, 0xf9, 0xa4, 0xb0,
								0x99, 0x92, 0x82, 0xf8,
								0x80, 0x90, 0x88, 0x83,
								0xc6, 0xa1, 0x86, 0x8e
								};
u8 code bit_tab[] = {
								0x80, 0x40, 0x20, 0x10,
								0x08, 0x04, 0x02, 0x01
								};
//�ӳٺ���
void delay(u16 num)
{
	u16 x,y;
	for(x = num; x > 0; x--)
		for(y = 110;  y > 0; y--)
		{
			;
		}
}
//�������ʾ����
void display_led(u8 which_bit, u8 which_num)
{
	bit_sel = 1;//D[7..0] = Q[7..0]
	DATA = bit_tab[which_bit];
	bit_sel = 0;//BIT[7..0] = 0X80
	seg_sel = 1;//D[7..0] = Q[7..0]
	DATA = seg_tab[which_num];
	seg_sel = 0;
	delay(5);
	
	P0 =0X00;//�������棬����Ӱ
}

void main()
{
	u16 num = 0;
	u16 ge = 0;
	u16 shi = 0;
	u16 bai = 0;
	int i = 0;
	
	P0 = 0xff;
	P1 = 0xff;//�˿ڳ�ʼ��
	seg_sel = 0;//LE��ֹ����
	bit_sel = 0;//LE��ֹ����
	while(1)
	{
		//for(num = 0; num <=9; num++)
			//display_led(0, num);
		i = 70;
		while(i--)
		{
			ge = num%10;
			shi = num/10;
			bai = num/100;
			display_led(0,ge);
			display_led(1,shi);
			display_led(2,bai);
		}
		num = num + 1;
		if(num == 1000)
		{
			num = 0;
		}
	}
}