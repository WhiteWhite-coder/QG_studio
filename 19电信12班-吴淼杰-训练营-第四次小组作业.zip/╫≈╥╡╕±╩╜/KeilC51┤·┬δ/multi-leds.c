#include <reg52.h>
typedef unsigned int  u16;
typedef unsigned char u8;
#define PORT P1
sbit buzzer = P0^0;
/*
sbit led1 = P1^0;
sbit led2 = P1^1;
sbit led3 = P1^2;
sbit led4 = P1^3;
sbit led5 = P1^4;
sbit led6 = P1^5;
sbit led7 = P1^6;
sbit led8 = P1^7;
*/
void delay(u16 num)
{
	u16 x,y;
	for(x = num; x > 0; x--)
		for(y = 110;  y > 0; y--)
		{
			;
		}
}
void main()
{
	u8 num,temp_val;
	PORT = 0xff;
	while(1)
	{
		PORT = 0xfe;
		temp_val = 0xfe;
		delay(500);
		for(num = 7; num > 0; num--)
		{
			temp_val = (temp_val << 1) | 0x01;
			PORT = temp_val;
			buzzer = 0;
			delay(100);
			buzzer = 1;
			delay(100);
			delay(300);
		}
	}
	/*
	P1 = 0xff;//LED���ģʽ LEDȫϨ��
	while(1)
	{
		led1 = 0;
		delay(500);
		led1 = 1;
		led2 = 0;
		delay(500);
		led2 = 1;
		led3 = 0;
		delay(500);
		led3 = 1;
		led4 = 0;
		delay(500);
		led4 = 1;
		led5 = 0;
		delay(500);
		led5 = 1;
		led6 = 0;
		delay(500);
		led6 = 1;
		led7 = 0;
		delay(500);
		led7 = 1;
		led8 = 0;
		delay(500);
		led8 = 1;
	}
	*/
}
