#include <stdio.h>
#include "linkedList.h"

/**
 *  @name        : Status InitList(LinkList *L);
 *	@description : initialize an empty linked list with only the head node without value
 *	@param		 : L(the head node)
 *	@return		 : Status
 *  @notice      : None
 */
Status InitList(LinkedList* L) {
    *L = (LinkedList)malloc(sizeof(LNode));//��̬�ڴ����룬��Ϊ�ṹ�����
    if ((*L) == NULL) {
        printf("\t����Ϊ�գ�����ʧ��");
        return ERROR;
    }
    (*L)->next = NULL;
    return SUCCESS;
}

/**
 *  @name        : void DestroyList(LinkedList *L)
 *	@description : destroy a linked list, free all the nodes
 *	@param		 : L(the head node)
 *	@return		 : None
 *  @notice      : None
 */
void DestroyList(LinkedList* L) {
    LinkedList p;
    while ((*L)->next != NULL) {
        p = (*L)->next;
        (*L)->next = (*L)->next->next;
        free(p);
    }
}

/**
 *  @name        : Status InsertList(LNode *p, LNode *q)
 *	@description : insert node q after node p
 *	@param		 : p, q
 *	@return		 : Status
 *  @notice      : None
 */
Status InsertList(LNode* p, LNode* q) {
    if (p == NULL) {
        return ERROR;
    }
    q->next = p->next;
    p->next = q;
    return SUCCESS;
}

/**
 *  @name        : Status DeleteList(LNode *p, ElemType *e)
 *	@description : delete the first node after the node p and assign its value to e
 *	@param		 : p, e
 *	@return		 : Status
 *  @notice      : None
 */
Status DeleteList(LNode* p, ElemType* e) {
    if (p == NULL && p->next == NULL) {
        return ERROR;
    }
    LinkedList q;
    q = p->next;
    *e = q->data;
    p->next = q->next;
    free(q);
    return SUCCESS;
}

/**
 *  @name        : void TraverseList(LinkedList L, void (*visit)(ElemType e))
 *	@description : traverse the linked list and call the funtion visit
 *	@param		 : L(the head node), visit
 *	@return		 : None
 *  @notice      : None
 */
void TraverseList(LinkedList L, void (*visit)(ElemType e)) {
    LNode* p;
    p = L->next;
    while (p != NULL) {
        if (p->next != NULL) {
            visit(p->data);
            printf("->");
        }
        else {
            visit(p->data);
        }
        p = p->next;
    }
}

/**
 *  @name        : Status SearchList(LinkedList L, ElemType e)
 *	@description : find the first node in the linked list according to e
 *	@param		 : L(the head node), e
 *	@return		 : Status
 *  @notice      : None
 */
Status SearchList(LinkedList L, ElemType e) {
    LinkedList p;
    p = L->next;
    while (p) {
        if (p->data != e)
            p = p->next;
        else
            return SUCCESS;
    }
    return ERROR;
}

/**
 *  @name        : Status ReverseList(LinkedList *L)
 *	@description : reverse the linked list
 *	@param		 : L(the head node)
 *	@return		 : Status
 *  @notice      : None
 */
Status ReverseList(LinkedList* L) {
    if ((*L) == NULL && (*L)->next == NULL) {
        return ERROR;
    }
    LinkedList now, Next;
    now = (*L)->next;
    while (now->next != NULL)//�ж��Ƿ�Ϊ��һ����ֵ������
    {
        Next = now->next;
        now->next = Next->next;
        Next->next = (*L)->next;
        (*L)->next = Next;//ÿһ�ζ�����ǰ��ֵ�嵽ǰ��ȥ
    }
    return SUCCESS;
}

/**
 *  @name        : Status IsLoopList(LinkedList L)
 *	@description : judge whether the linked list is looped
 *	@param		 : L(the head node)
 *	@return		 : Status
 *  @notice      : None
 */
Status IsLoopList(LinkedList L) {
    if (L->next == NULL) {
        return ERROR;
    }
    LinkedList p = L;
    while (p->next != NULL && p->next != L) {//��һ����������һλ��ֱ�����
        p = p->next;
    }
    if (p->next == NULL) {//������һ��Ϊ�գ���Ϊ��
        return ERROR;
    }
    else {
        return SUCCESS;//������һ����Ϊ�գ���Ϊ��
    }
}

/**
 *  @name        : LNode* ReverseEvenList(LinkedList *L)
 *	@description : reverse the nodes which value is an even number in the linked list, input: 1 -> 2 -> 3 -> 4  output: 2 -> 1 -> 4 -> 3
 *	@param		 : L(the head node)
 *	@return		 : LNode(the new head node)
 *  @notice      : choose to finish
 */
LNode* ReverseEvenList(LinkedList* L) {
    if ((*L) == NULL && (*L)->next == NULL) {
        return L;
    }
    LinkedList fast, slow ,now, result;
    result = (*L);
    now = (*L);
    while (now->next != NULL && now->next->next != NULL) {
        slow = now->next;//node1
        fast = now->next->next;//node2

        slow->next = fast->next;
        fast->next = now->next;
        now->next = fast;//�������

        now = now->next->next;//��һ��
    }
    return result;
}

/**
 *  @name        : LNode* FindMidNode(LinkedList *L)
 *	@description : find the middle node in the linked list
 *	@param		 : L(the head node)
 *	@return		 : LNode
 *  @notice      : choose to finish
 */
LNode* FindMidNode(LinkedList* L) {
    LinkedList fast, slow;
    fast = (*L);
    slow = (*L);
    while (fast != NULL && fast->next != NULL) {
        fast = fast->next->next;//��������
        slow = slow->next;//��һ��
    }
    return slow;
}

