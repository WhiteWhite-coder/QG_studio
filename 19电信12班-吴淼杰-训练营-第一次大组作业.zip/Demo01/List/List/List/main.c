#include <stdio.h> 
#include "linkedList.h"

void visit(ElemType e)
{
	printf("%d ", e);
}

int main()
{

	return 0;
}