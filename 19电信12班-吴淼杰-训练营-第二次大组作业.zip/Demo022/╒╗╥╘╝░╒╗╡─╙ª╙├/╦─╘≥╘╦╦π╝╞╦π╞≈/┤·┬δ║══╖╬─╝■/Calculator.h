#include <stdio.h> 
#include <stdlib.h>
#ifndef STACK_H_INCLUDED
#define STACK_H_INCLUDED

typedef enum Status
{
    ERROR = 0,
    SUCCESS = 1
} Status;

typedef  struct StackNode
{
    char cData;
    int data;
    struct StackNode* next;
}StackNode, * LinkStackPtr;

typedef  struct  LinkStack {
    LinkStackPtr top;
    int	count;
}LinkStack;


Status initLStack(LinkStack* s);//��ʼ��ջ
Status isEmptyLStack(LinkStack* s);//�ж�ջ�Ƿ�Ϊ��
int    getTopLStackint(LinkStack* s);//�õ�ջ��Ԫ��
char   getTopLStackchar(LinkStack* s);//�õ�ջ��Ԫ��
Status destroyLStack(LinkStack* s);//����ջ
Status pushLStackint(LinkStack* s, int data);//��ջ
Status pushLStackchar(LinkStack* s, char data);//��ջ
Status popLStackint(LinkStack* s, int* data);//��ջ
Status popLStackchar(LinkStack* s, char* data);//��ջ
int Priority(char ch);

#endif 