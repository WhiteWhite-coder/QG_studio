#include <stdio.h> 
#include <stdlib.h>
#include "Calculator.h"

Status initLStack(LinkStack* s)   //��ʼ��
{
    s->count = 0;
    s->top = (LinkStackPtr)malloc(sizeof(StackNode));
    if (s->top == NULL)
    {
        return ERROR;
    }
    else
    {
        s->top = NULL;
    }
    return SUCCESS;
}

Status isEmptyLStack(LinkStack* s)  //�ж���ջ�Ƿ�Ϊ��
{
    /*if (s->count == 0)
    {
        return SUCCESS;
    }
    return ERROR;*/

    return s->top == NULL ? SUCCESS : ERROR;
}

int getTopLStackint(LinkStack* s)  //�õ�ջ��Ԫ��
{
    return (s->top->data);
}

char getTopLStackchar(LinkStack* s)  //�õ�ջ��Ԫ��
{
    return (s->top->cData);
}

Status destroyLStack(LinkStack* s)   //����ջ
{
    if (isEmptyLStack(s))
        return ERROR;
    while (s->top != NULL)
    {
        LinkStackPtr p = s->top;
        s->top = s->top->next;
        free(p);
    }
    s->count = 0;
    return SUCCESS;
}

Status pushLStackint(LinkStack* s, int data)   //��ջ
{
    LinkStackPtr p = (LinkStackPtr)malloc(sizeof(StackNode));
    if (p == NULL)
    {
        return ERROR;
    }
    p->data = data;
    p->next = s->top;
    s->top = p;
    s->count++;

    return SUCCESS;
}

Status pushLStackchar(LinkStack* s, char data)   //��ջ
{
    LinkStackPtr p = (LinkStackPtr)malloc(sizeof(StackNode));
    if (p == NULL)
    {
        return ERROR;
    }
    p->cData = data;
    p->next = s->top;
    s->top = p;
    s->count++;

    return SUCCESS;
}

Status popLStackint(LinkStack* s, int* data)   //��ջ
{
    if (isEmptyLStack(s))
        return ERROR;
    *data = s->top->data;
    LinkStackPtr p = s->top;
    s->top = p->next;
    free(p);
    p = NULL;
    s->count--;
    return SUCCESS;
}

Status popLStackchar(LinkStack* s, char* data)   //��ջ
{
    if (isEmptyLStack(s))
        return ERROR;
    *data = s->top->cData;
    LinkStackPtr p = s->top;
    s->top = p->next;
    free(p);
    p = NULL;
    s->count--;
    return SUCCESS;
}

int Priority(char ch)
{
    switch (ch)
    {
    case '(':
        return 3;//      ��   ����
    case '*':
    case '/':
        return 2;//       * / ����
    case '+':
    case '-':
        return 1;//       + - һ��
    default :
        return 0;//            0��
    }
}
