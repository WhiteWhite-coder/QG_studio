#pragma once
#include <stdio.h> 
#include <stdlib.h>

int menu();
