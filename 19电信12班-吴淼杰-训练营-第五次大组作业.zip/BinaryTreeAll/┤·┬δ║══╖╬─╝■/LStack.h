/***************************************************************************************
 *	File Name				:	BinaryTree.h
 *	SYSTEM					:   win10
 *	Create Data				:	2020.4.26
 *
 *
 *--------------------------------Revision History--------------------------------------
 *	No	version		Data			Revised By			Item			Description
 *
 *
 ***************************************************************************************/

 /**************************************************************
*	Multi-Include-Prevent Section
**************************************************************/
#define _CRT_SECURE_NO_WARNINGS
#ifndef STACK_H_INCLUDED
#define STACK_H_INCLUDED
#include "BinaryTree.h"

/**************************************************************
*	Struct Define Section
**************************************************************/
typedef BiTree ElemType;

typedef  struct StackNode
{
	ElemType data;
	struct StackNode* next;
}StackNode, * LinkStackPtr;

typedef  struct  LinkStack {
	LinkStackPtr top;
	int	count;
}LinkStack;

/**************************************************************
*	Prototype Declare Section
**************************************************************/

/**
 *  @name        : Status initLStack(LinkStack* s);
 *  @description : ��ʼ��ջ
 *  @param       : ����ջ���s
 */
Status initLStack(LinkStack* s);

/**
 *  @name        : Status isEmptyLStack(LinkStack* s);
 *  @description : �ж�ջ�Ƿ�Ϊ��
 *  @param       : ����ջ���s
 */
Status isEmptyLStack(LinkStack* s);

/**
 *  @name        : Status pushLStack(LinkStack* s, ElemType data);
 *  @description : ��ջ
 *  @param       : ����ջ���s����ջ��ֵdata
 */
Status pushLStack(LinkStack* s, ElemType data);

/**
 *  @name        : Status popLStack(LinkStack* s, ElemType* data);
 *  @description : ��ջ
 *  @param       : ����ջ���s����ջ��ֵdata
 */
Status popLStack(LinkStack* s, ElemType* data);

/**************************************************************
*	End-Multi-Include-Prevent Section
**************************************************************/
#endif