#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"LStack.h"

StackNode* bottom = NULL;

/**
 *  @name        : Status initLStack(LinkStack* s);
 *  @description : ��ʼ��ջ
 *  @param       : ����ջ���s
 */
Status initLStack(LinkStack* s)
{
	if (s->top == NULL)
	{
		if ((s->top = (LinkStackPtr)malloc(sizeof(StackNode))) == NULL)
		{
			printf("\t\t\t\t�ڴ����ʧ��\n");
			exit(0);
		}
		s->top->next = NULL;
		s->count = 0;
		return SUCEESS;
	}
	else
	{
		return ERROR;
	}
}

/**
 *  @name        : Status isEmptyLStack(LinkStack* s);
 *  @description : �ж�ջ�Ƿ�Ϊ��
 *  @param       : ����ջ���s
 */
Status isEmptyLStack(LinkStack* s)
{
	if (s->count == 0)
	{
		return SUCEESS;
	}
	return ERROR;
}

/**
 *  @name        : Status pushLStack(LinkStack* s, ElemType data);
 *  @description : ��ջ
 *  @param       : ����ջ���s����ջ��ֵdata
 */
Status pushLStack(LinkStack* s, ElemType data)
{
	LinkStackPtr p;
	p = (LinkStackPtr)malloc(sizeof(StackNode));
	if (p == NULL)
	{
		printf("\t\t\t\t�ڴ����ʧ��\n");
		exit(0);
	}
	p->data = data;
	p->next = s->top->next;
	s->top->next = p;
	s->count++;
	return SUCEESS;
}

/**
 *  @name        : Status popLStack(LinkStack* s, ElemType* data);
 *  @description : ��ջ
 *  @param       : ����ջ���s����ջ��ֵdata
 */
Status popLStack(LinkStack* s, ElemType* data)
{
	LinkStackPtr p;
	if (s->count != 0)
	{
		p = s->top->next;
		*data = p->data;
		s->top->next = p->next;
		free(p);
		s->count--;
		return SUCEESS;
	}
	else
	{
		return ERROR;
	}
}